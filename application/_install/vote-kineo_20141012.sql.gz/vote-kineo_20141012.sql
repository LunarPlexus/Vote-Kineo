# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.9)
# Database: vote-kineo
# Generation Time: 2014-10-12 04:16:49 -0500
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `vote-kineo`;

USE `vote-kineo`;

# Dump of table candidates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `candidates`;

CREATE TABLE `candidates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `candidate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `candidates` WRITE;
/*!40000 ALTER TABLE `candidates` DISABLE KEYS */;

INSERT INTO `candidates` (`id`, `candidate`)
VALUES
	(1,'P Pig'),
	(2,'Don Duck'),
	(3,'M Mouse'),
	(4,'Mister Moose'),
	(5,'None of the above');

/*!40000 ALTER TABLE `candidates` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tbl_state
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_state`;

CREATE TABLE `tbl_state` (
  `state_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'PK: Unique state ID',
  `state_name` varchar(32) NOT NULL COMMENT 'State name with first letter capital',
  `state_abbr` varchar(8) DEFAULT NULL COMMENT 'Optional state abbreviation (US is 2 capital letters)',
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `tbl_state` WRITE;
/*!40000 ALTER TABLE `tbl_state` DISABLE KEYS */;

INSERT INTO `tbl_state` (`state_id`, `state_name`, `state_abbr`)
VALUES
	(1,'Alabama','AL'),
	(2,'Alaska','AK'),
	(3,'Arizona','AZ'),
	(4,'Arkansas','AR'),
	(5,'California','CA'),
	(6,'Colorado','CO'),
	(7,'Connecticut','CT'),
	(8,'Delaware','DE'),
	(9,'District of Columbia','DC'),
	(10,'Florida','FL'),
	(11,'Georgia','GA'),
	(12,'Hawaii','HI'),
	(13,'Idaho','ID'),
	(14,'Illinois','IL'),
	(15,'Indiana','IN'),
	(16,'Iowa','IA'),
	(17,'Kansas','KS'),
	(18,'Kentucky','KY'),
	(19,'Louisiana','LA'),
	(20,'Maine','ME'),
	(21,'Maryland','MD'),
	(22,'Massachusetts','MA'),
	(23,'Michigan','MI'),
	(24,'Minnesota','MN'),
	(25,'Mississippi','MS'),
	(26,'Missouri','MO'),
	(27,'Montana','MT'),
	(28,'Nebraska','NE'),
	(29,'Nevada','NV'),
	(30,'New Hampshire','NH'),
	(31,'New Jersey','NJ'),
	(32,'New Mexico','NM'),
	(33,'New York','NY'),
	(34,'North Carolina','NC'),
	(35,'North Dakota','ND'),
	(36,'Ohio','OH'),
	(37,'Oklahoma','OK'),
	(38,'Oregon','OR'),
	(39,'Pennsylvania','PA'),
	(40,'Rhode Island','RI'),
	(41,'South Carolina','SC'),
	(42,'South Dakota','SD'),
	(43,'Tennessee','TN'),
	(44,'Texas','TX'),
	(45,'Utah','UT'),
	(46,'Vermont','VT'),
	(47,'Virginia','VA'),
	(48,'Washington','WA'),
	(49,'West Virginia','WV'),
	(50,'Wisconsin','WI'),
	(51,'Wyoming','WY');

/*!40000 ALTER TABLE `tbl_state` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table voters
# ------------------------------------------------------------

DROP TABLE IF EXISTS `voters`;

CREATE TABLE `voters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `isVoting` tinyint(4) DEFAULT NULL,
  `forWhom` varchar(100) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `voters` WRITE;
/*!40000 ALTER TABLE `voters` DISABLE KEYS */;

INSERT INTO `voters` (`id`, `isVoting`, `forWhom`, `state`)
VALUES
	(1,1,'Mister Moose','IL'),
	(2,1,'Don Duck','MN'),
	(3,0,'M Mouse','TX'),
	(4,0,'P Pig','OK'),
	(5,1,'None of the above','AK'),
	(6,1,'Mister Moose','FL'),
	(7,1,'Mister Moose','IL'),
	(8,1,'Blech','IL'),
	(9,1,'M Mouse','TX'),
	(10,1,'P Pig','TX'),
	(11,1,'P Pig','TX'),
	(12,1,'P Pig','IL'),
	(13,1,'P Pig','OH'),
	(14,1,'Don Duck','IL'),
	(15,1,'None of the above','GA'),
	(16,1,'Don Duck','ME'),
	(17,1,'M Mouse','TX'),
	(18,0,'P Pig','AZ'),
	(19,1,'M Mouse','CA'),
	(20,1,'Anybody Else','CA'),
	(21,1,'Anybody Else','IA'),
	(22,1,'Anybody Else','AK'),
	(23,1,'Anybody Else','AR'),
	(24,1,'P Pig','AR'),
	(25,1,'P Pig','AR'),
	(26,1,'P Pig','AR'),
	(27,1,'P Pig','Se'),
	(28,1,'P Pig','Se'),
	(29,1,'You','CO'),
	(30,1,'Don Duck','AL'),
	(31,1,'Some Guy','AL'),
	(32,1,'M Mouse','AZ'),
	(33,1,'Somebody Else','CO'),
	(34,0,'Myself','DE'),
	(35,0,'Mister Moose','VT'),
	(36,0,'Don Duck','CO'),
	(37,1,'Don Duck','CO'),
	(38,1,'Don Duck','CO'),
	(39,1,'Don Duck','CO'),
	(40,1,'Don Duck','CO'),
	(41,1,'Don Duck','CO'),
	(42,1,'Don Duck','CO'),
	(43,0,'None of the above','CA'),
	(44,1,'Somebody Else','CA'),
	(45,1,'Somebody Else','DE'),
	(46,1,'M Mouse','FL'),
	(47,1,'Somebody Else','GA'),
	(48,1,'Me','AZ'),
	(49,1,'Daffy','WA');

/*!40000 ALTER TABLE `voters` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
